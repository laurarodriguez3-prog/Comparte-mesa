# 🍲 ComparteMesa

Plataforma social en Azure que conecta **donantes de comida** (restaurantes, mercados, bodegas) con **ollas comunes y comedores populares**, para rescatar alimentos aptos antes de que se desperdicien.

## ODS que atiende

| ODS | Cómo contribuye |
|---|---|
| **ODS 2 – Hambre cero** | Lleva comida disponible a quienes la necesitan. |
| **ODS 12 – Producción y consumo responsables** | Reduce el desperdicio de alimentos (meta 12.3). |
| **ODS 1 – Fin de la pobreza** | Apoya a organizaciones comunitarias que atienden a familias vulnerables. |
| **ODS 17 – Alianzas** | Une sector privado, comunidad y organizaciones sociales en una sola plataforma. |

## Qué hace

1. Un donante publica lo que le sobra (qué, cuántos kg, distrito, hasta qué hora).
2. Una organización ve las donaciones disponibles y **reclama** una (control de concurrencia: solo una puede ganarla).
3. El panel muestra el **impacto**: kg rescatados, raciones y CO₂e evitado (estimaciones con factores configurables).
4. Un **asistente de IA** (Azure AI Foundry / Azure OpenAI) orienta sobre inocuidad y cómo describir la donación.

## Arquitectura (alineada con las clases del bootcamp)

```
Usuario ──HTTPS──► App Service (Linux, Python/FastAPI)
                      │  Managed Identity (sin contraseñas)
                      ├──► Azure Table Storage   (donaciones)
                      ├──► Key Vault              (secretos, RBAC)
                      ├──► Azure OpenAI / Foundry (asistente, opcional)
                      └──► Application Insights + Log Analytics (monitoreo)

Bicep ──► crea toda la infraestructura       Azure DevOps ──► CI/CD (test → Bicep → deploy)
```

| Clase del bootcamp | Dónde se aplica |
|---|---|
| Plataforma Azure / Azure CLI y costos | `docs/DESPLIEGUE.md` (comandos `az`, estimación de costo) |
| Cómputo: App Service | `infra/main.bicep` (Plan B1 + Web App Linux) |
| Contenedores | `Dockerfile` (opcional: Azure Container Apps) |
| Almacenamiento | Storage Account + Table `donaciones` |
| Entra ID, RBAC, identidades administradas | Managed Identity + roles *Table Data Contributor* y *Key Vault Secrets User* |
| Secretos, cifrado y monitoreo | Key Vault, TLS 1.2, App Insights |
| Infraestructura como código | `infra/main.bicep` |
| Azure DevOps CI/CD | `azure-pipelines.yml` |
| Agentes de IA con Foundry | `app/assistant.py` |

## Probar en local (sin Azure)

```bash
python -m venv .venv && source .venv/bin/activate   # en Windows: .venv\Scripts\activate
pip install -r requirements.txt -r requirements-dev.txt
python -m pytest -q
uvicorn app.main:app --reload        # abre http://127.0.0.1:8000
```
Sin `STORAGE_ACCOUNT_NAME` usa memoria; los datos se pierden al reiniciar (solo para desarrollo).

## Desplegar en Azure

Ver **[docs/DESPLIEGUE.md](docs/DESPLIEGUE.md)**. Presentación del proyecto final: **[docs/PRESENTACION.md](docs/PRESENTACION.md)**.

## Estructura

```
app/            API FastAPI, almacenamiento, asistente IA y front (static/)
infra/          Bicep (main.bicep + main.bicepparam)
tests/          Pruebas con pytest
docs/           Despliegue y guion de presentación
azure-pipelines.yml   CI/CD
Dockerfile      Imagen opcional para Container Apps
```

## Limitaciones conocidas (honestidad técnica)

- La app no tiene autenticación de usuarios: cualquiera puede publicar o reclamar. Para producción, agregar **Microsoft Entra External ID** o el login integrado de App Service (*Easy Auth*).
- Las raciones por kg y el CO₂e son **estimaciones**; valídalas con una fuente oficial antes de reportarlas.
- Table Storage es suficiente para el MVP; para búsquedas geográficas conviene Cosmos DB o Azure SQL.
