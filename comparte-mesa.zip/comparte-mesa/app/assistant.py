"""Asistente de IA (Azure AI Foundry / Azure OpenAI). Opcional: si no hay endpoint, usa respuestas guía."""
import os

SISTEMA = (
    "Eres el asistente de ComparteMesa, una plataforma que conecta donantes de comida "
    "(restaurantes, mercados, bodegas) con ollas comunes y comedores populares en Perú. "
    "Ayudas a: redactar la descripción de una donación, recordar buenas prácticas de "
    "inocuidad (cadena de frío, fecha de consumo, empaque) y orientar sobre cómo reclamar "
    "una donación. Responde en español, breve y amable. No des consejos médicos."
)


def responder(pregunta: str) -> str:
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o-mini")
    if not endpoint:
        return (
            "Modo demostración (sin IA configurada). Consejos rápidos: mantén los alimentos "
            "perecibles refrigerados, indica la hora límite de consumo y usa envases limpios. "
            "Configura AZURE_OPENAI_ENDPOINT para activar el asistente con IA."
        )
    from azure.identity import DefaultAzureCredential, get_bearer_token_provider
    from openai import AzureOpenAI

    token_provider = get_bearer_token_provider(
        DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default"
    )
    client = AzureOpenAI(
        azure_endpoint=endpoint,
        azure_ad_token_provider=token_provider,
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21"),
    )
    r = client.chat.completions.create(
        model=deployment,
        messages=[{"role": "system", "content": SISTEMA}, {"role": "user", "content": pregunta}],
        max_tokens=300,
        temperature=0.3,
    )
    return r.choices[0].message.content or ""
