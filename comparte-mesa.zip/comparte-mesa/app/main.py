"""ComparteMesa API — ODS 2 (Hambre cero), 12 (Producción y consumo responsables), 1 y 17."""
import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .assistant import responder
from .store import ConflictError, get_store

if os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING"):
    try:
        from azure.monitor.opentelemetry import configure_azure_monitor

        configure_azure_monitor()
    except Exception:  # la telemetría nunca debe tumbar la app
        logging.exception("No se pudo configurar Application Insights")

app = FastAPI(title="ComparteMesa API", version="1.0.0")
store = get_store()
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")

# Factores de estimación (ajustables por variable de entorno)
RACIONES_POR_KG = float(os.getenv("RACIONES_POR_KG", "2.5"))
CO2E_POR_KG = float(os.getenv("CO2E_POR_KG", "2.5"))


class DonacionIn(BaseModel):
    donante: str = Field(min_length=2, max_length=80)
    descripcion: str = Field(min_length=3, max_length=300)
    kg: float = Field(gt=0, le=2000)
    distrito: str = Field(min_length=2, max_length=60)
    hora_limite: str = Field(min_length=3, max_length=40, description="Ej: hoy 9:00 p. m.")


class Reclamo(BaseModel):
    organizacion: str = Field(min_length=2, max_length=80)


class Pregunta(BaseModel):
    texto: str = Field(min_length=2, max_length=500)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/api/donaciones", status_code=201)
def crear_donacion(d: DonacionIn):
    item = {
        "id": uuid.uuid4().hex[:12],
        "estado": "disponible",
        "organizacion": "",
        "creado": datetime.now(timezone.utc).isoformat(),
        **d.model_dump(),
    }
    return store.add(item)


@app.get("/api/donaciones")
def listar(estado: Optional[str] = Query(None, pattern="^(disponible|reclamada)$")):
    return store.list(estado)


@app.post("/api/donaciones/{id_}/reclamar")
def reclamar(id_: str, r: Reclamo):
    try:
        return store.claim(id_, r.organizacion)
    except KeyError:
        raise HTTPException(404, "Donación no encontrada")
    except ConflictError as e:
        raise HTTPException(409, str(e))


@app.get("/api/impacto")
def impacto():
    reclamadas = store.list("reclamada")
    kg = round(sum(float(i["kg"]) for i in reclamadas), 1)
    return {
        "donaciones_entregadas": len(reclamadas),
        "kg_rescatados": kg,
        "raciones_estimadas": round(kg * RACIONES_POR_KG),
        "co2e_evitado_kg_estimado": round(kg * CO2E_POR_KG, 1),
        "ods": ["ODS 2", "ODS 12", "ODS 1", "ODS 17"],
        "nota": "Raciones y CO2e son estimaciones con factores configurables.",
    }


@app.post("/api/asistente")
def asistente(p: Pregunta):
    try:
        return {"respuesta": responder(p.texto)}
    except Exception:
        logging.exception("Fallo del asistente")
        raise HTTPException(502, "El asistente no está disponible en este momento")


@app.get("/")
def home():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
