"""Capa de datos: Azure Table Storage en la nube, memoria en local."""
import os
import threading
from typing import Optional


class ConflictError(Exception):
    pass


class MemoryStore:
    """Almacén en memoria para desarrollo local y pruebas."""

    def __init__(self):
        self._data: dict[str, dict] = {}
        self._lock = threading.Lock()

    def add(self, d: dict) -> dict:
        with self._lock:
            self._data[d["id"]] = dict(d)
        return d

    def list(self, estado: Optional[str] = None) -> list[dict]:
        items = list(self._data.values())
        if estado:
            items = [i for i in items if i["estado"] == estado]
        return sorted(items, key=lambda i: i["creado"], reverse=True)

    def claim(self, id_: str, organizacion: str) -> dict:
        with self._lock:
            d = self._data.get(id_)
            if d is None:
                raise KeyError(id_)
            if d["estado"] != "disponible":
                raise ConflictError("La donación ya fue reclamada")
            d["estado"] = "reclamada"
            d["organizacion"] = organizacion
            return dict(d)


class TableStore:
    """Almacén en Azure Table Storage usando Managed Identity (sin secretos)."""

    def __init__(self, account_name: str):
        from azure.data.tables import TableServiceClient
        from azure.identity import DefaultAzureCredential

        svc = TableServiceClient(
            endpoint=f"https://{account_name}.table.core.windows.net",
            credential=DefaultAzureCredential(),
        )
        self.t = svc.get_table_client("donaciones")

    @staticmethod
    def _to_dict(e) -> dict:
        d = dict(e)
        d["id"] = d.pop("RowKey")
        d.pop("PartitionKey", None)
        return d

    def add(self, d: dict) -> dict:
        body = {k: v for k, v in d.items() if k != "id"}
        self.t.create_entity({"PartitionKey": "donacion", "RowKey": d["id"], **body})
        return d

    def list(self, estado: Optional[str] = None) -> list[dict]:
        flt = f"estado eq '{estado}'" if estado else None
        items = [self._to_dict(e) for e in self.t.query_entities(flt)] if flt \
            else [self._to_dict(e) for e in self.t.list_entities()]
        return sorted(items, key=lambda i: i["creado"], reverse=True)

    def claim(self, id_: str, organizacion: str) -> dict:
        from azure.core import MatchConditions
        from azure.core.exceptions import ResourceModifiedError, ResourceNotFoundError

        try:
            e = self.t.get_entity("donacion", id_)
        except ResourceNotFoundError:
            raise KeyError(id_)
        if e["estado"] != "disponible":
            raise ConflictError("La donación ya fue reclamada")
        etag = e.metadata["etag"]
        e["estado"] = "reclamada"
        e["organizacion"] = organizacion
        try:
            self.t.update_entity(e, mode="merge", etag=etag,
                                 match_condition=MatchConditions.IfNotModified)
        except ResourceModifiedError:
            raise ConflictError("Otra organización la reclamó primero")
        return self._to_dict(e)


def get_store():
    account = os.getenv("STORAGE_ACCOUNT_NAME")
    return TableStore(account) if account else MemoryStore()
