# Guía de despliegue en Azure

Requisitos: cuenta de Azure con suscripción activa, [Azure CLI](https://learn.microsoft.com/cli/azure/install-azure-cli) y `az bicep` (`az bicep install`).

## 1. Iniciar sesión y crear el grupo de recursos

```bash
az login
az account set --subscription "<TU_SUSCRIPCION>"
az group create -n rg-comparte-dev -l eastus2
```

## 2. Desplegar la infraestructura con Bicep

```bash
az bicep build --file infra/main.bicep          # valida la sintaxis
az deployment group create -g rg-comparte-dev -f infra/main.bicep -p infra/main.bicepparam
```
Guarda el nombre de la app: 
```bash
APP=$(az deployment group show -g rg-comparte-dev -n main --query properties.outputs.webAppName.value -o tsv)
```

## 3. Publicar el código

```bash
zip -r app.zip . -x ".git/*" ".venv/*" "tests/*" "docs/*"
az webapp deploy -g rg-comparte-dev -n $APP --src-path app.zip --type zip
```
Abre `https://<APP>.azurewebsites.net` y prueba `/health`.

## 4. (Opcional) Activar el asistente de IA con Foundry

1. En el portal de **Azure AI Foundry**, crea un proyecto y despliega un modelo (por ejemplo `gpt-4o-mini`).
2. Copia el endpoint del recurso y actualiza `infra/main.bicepparam` (`openAiEndpoint`), luego vuelve a ejecutar el paso 2.
3. Da permiso a la identidad de la app (sin claves):
```bash
PID=$(az webapp identity show -g rg-comparte-dev -n $APP --query principalId -o tsv)
az role assignment create --assignee $PID --role "Cognitive Services OpenAI User" \
  --scope <ID_DEL_RECURSO_OPENAI>
```

## 5. CI/CD con Azure DevOps

1. Crea un proyecto en Azure DevOps y sube este repositorio.
2. En *Project settings → Service connections*, crea una conexión **Azure Resource Manager** y copia su nombre en `AZURE_SERVICE_CONNECTION` de `azure-pipelines.yml`.
3. Crea un *Environment* llamado `dev` y ejecuta el pipeline.

## 6. Contenedor (opcional)

```bash
az acr create -g rg-comparte-dev -n <acrnombreunico> --sku Basic
az acr build -r <acrnombreunico> -t comparte:v1 .
```
Luego crea una Azure Container App con esa imagen (clase de contenedores).

## 7. Costos y limpieza

- App Service B1 (Linux) cuesta aproximadamente 13 USD/mes; Storage y Log Analytics a este volumen son centavos. **Verifica precios actuales en la calculadora de Azure**, pues cambian.
- Para no gastar créditos, elimina todo al terminar:
```bash
az group delete -n rg-comparte-dev --yes --no-wait
```
- Revisa tu consumo con `az consumption usage list` o en *Cost Management* (clase de Azure CLI y costos).
