# Guion de presentación — Proyecto final (5–7 min)

**1. Problema (45 s).** Cada día se desperdician alimentos aptos para consumo mientras hay familias con hambre. Falta un canal simple que conecte a quien sobra con quien necesita.

**2. Solución (45 s).** ComparteMesa: donantes publican excedentes, ollas comunes los reclaman en minutos, y un panel muestra el impacto.

**3. ODS (30 s).** ODS 2, 12 (meta 12.3), 1 y 17.

**4. Demo (2 min).**
- Publicar una donación.
- Reclamarla desde otra "organización".
- Intentar reclamarla otra vez → conflicto 409 (control de concurrencia).
- Ver los KPIs de impacto.
- Preguntar al asistente de IA sobre empaque de comida cocida.

**5. Arquitectura Azure (1.5 min).** App Service + Table Storage + Key Vault + Managed Identity + App Insights; todo creado con Bicep y desplegado con Azure DevOps.

**6. Seguridad y costos (45 s).** Sin contraseñas (identidad administrada + RBAC), TLS 1.2, HTTPS obligatorio, secretos en Key Vault. Costo aproximado: plan B1 + centavos de almacenamiento.

**7. Siguientes pasos (30 s).** Autenticación con Entra External ID, notificaciones por WhatsApp/Email, mapa con rutas de recojo, alianza con municipalidades y bancos de alimentos.

## Posibles preguntas del jurado

- *¿Cómo garantizas la inocuidad?* El asistente recuerda buenas prácticas, pero la responsabilidad sanitaria sigue siendo del donante y la organización; se puede agregar un checklist obligatorio.
- *¿Por qué Table Storage?* Costo mínimo y simplicidad para el MVP; escalar a Cosmos DB si se requieren consultas geográficas.
- *¿Cómo evitas que dos organizaciones reclamen lo mismo?* Actualización con ETag (concurrencia optimista) en Table Storage.
