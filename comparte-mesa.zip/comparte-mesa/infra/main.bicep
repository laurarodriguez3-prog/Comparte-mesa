// ComparteMesa — infraestructura como código (Bicep)
// Despliegue:  az deployment group create -g rg-comparte-dev -f infra/main.bicep -p infra/main.bicepparam
targetScope = 'resourceGroup'

@description('Región de Azure')
param location string = resourceGroup().location

@description('Prefijo del proyecto (minúsculas, máx. 10 caracteres)')
@maxLength(10)
param projectName string = 'comparte'

@allowed(['dev', 'prod'])
param env string = 'dev'

@description('SKU del App Service Plan (B1 es suficiente para el bootcamp)')
param appServiceSku string = 'B1'

@description('Endpoint de Azure OpenAI / AI Foundry (opcional, déjalo vacío para modo demo)')
param openAiEndpoint string = ''

@description('Nombre del deployment del modelo')
param openAiDeployment string = 'gpt-4o-mini'

var suffix = uniqueString(resourceGroup().id)
var storageName = toLower('st${projectName}${env}${take(suffix, 6)}')
var kvName = 'kv-${projectName}-${env}-${take(suffix, 5)}'
var tags = {
  proyecto: 'ComparteMesa'
  ods: '2-12-1-17'
  entorno: env
}

// IDs de roles integrados de Azure
var roleTableDataContributor = '0a9a7e1f-b9d0-4cc4-a60d-0319b160aaa3' // Storage Table Data Contributor
var roleKeyVaultSecretsUser = '4633458b-17de-408a-b874-0445c86b69e6' // Key Vault Secrets User

// ---------- Monitoreo ----------
resource logs 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: 'log-${projectName}-${env}'
  location: location
  tags: tags
  properties: {
    sku: { name: 'PerGB2018' }
    retentionInDays: 30
  }
}

resource appi 'Microsoft.Insights/components@2020-02-02' = {
  name: 'appi-${projectName}-${env}'
  location: location
  kind: 'web'
  tags: tags
  properties: {
    Application_Type: 'web'
    WorkspaceResourceId: logs.id
  }
}

// ---------- Datos ----------
resource storage 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: storageName
  location: location
  tags: tags
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
    allowBlobPublicAccess: false
    supportsHttpsTrafficOnly: true
  }
}

resource tableSvc 'Microsoft.Storage/storageAccounts/tableServices@2023-05-01' = {
  parent: storage
  name: 'default'
}

resource tableDonaciones 'Microsoft.Storage/storageAccounts/tableServices/tables@2023-05-01' = {
  parent: tableSvc
  name: 'donaciones'
}

// ---------- Secretos ----------
resource kv 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: kvName
  location: location
  tags: tags
  properties: {
    tenantId: subscription().tenantId
    sku: { family: 'A', name: 'standard' }
    enableRbacAuthorization: true
    enableSoftDelete: true
    softDeleteRetentionInDays: 7
  }
}

// ---------- Cómputo ----------
resource plan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: 'asp-${projectName}-${env}'
  location: location
  tags: tags
  kind: 'linux'
  sku: { name: appServiceSku }
  properties: { reserved: true }
}

resource web 'Microsoft.Web/sites@2023-12-01' = {
  name: 'app-${projectName}-${env}-${take(suffix, 5)}'
  location: location
  tags: tags
  identity: { type: 'SystemAssigned' }
  properties: {
    serverFarmId: plan.id
    httpsOnly: true
    siteConfig: {
      linuxFxVersion: 'PYTHON|3.11'
      appCommandLine: 'gunicorn -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000 app.main:app'
      ftpsState: 'Disabled'
      minTlsVersion: '1.2'
      healthCheckPath: '/health'
      appSettings: [
        { name: 'WEBSITES_PORT', value: '8000' }
        { name: 'SCM_DO_BUILD_DURING_DEPLOYMENT', value: 'true' }
        { name: 'STORAGE_ACCOUNT_NAME', value: storage.name }
        { name: 'KEY_VAULT_URI', value: kv.properties.vaultUri }
        { name: 'APPLICATIONINSIGHTS_CONNECTION_STRING', value: appi.properties.ConnectionString }
        { name: 'AZURE_OPENAI_ENDPOINT', value: openAiEndpoint }
        { name: 'AZURE_OPENAI_DEPLOYMENT', value: openAiDeployment }
      ]
    }
  }
}

// ---------- Seguridad: identidad administrada + RBAC (sin contraseñas) ----------
resource roleTables 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(storage.id, web.id, roleTableDataContributor)
  scope: storage
  properties: {
    principalId: web.identity.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleTableDataContributor)
  }
}

resource roleKv 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(kv.id, web.id, roleKeyVaultSecretsUser)
  scope: kv
  properties: {
    principalId: web.identity.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleKeyVaultSecretsUser)
  }
}

output webAppName string = web.name
output webAppUrl string = 'https://${web.properties.defaultHostName}'
output storageAccount string = storage.name
output keyVaultUri string = kv.properties.vaultUri
output principalId string = web.identity.principalId
