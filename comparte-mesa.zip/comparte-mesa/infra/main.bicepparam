using 'main.bicep'

param projectName = 'comparte'
param env = 'dev'
param appServiceSku = 'B1'
// Pega aquí el endpoint de tu recurso de Azure OpenAI / AI Foundry si lo creas (opcional)
param openAiEndpoint = ''
param openAiDeployment = 'gpt-4o-mini'
