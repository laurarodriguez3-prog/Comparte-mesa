import os

os.environ.pop("STORAGE_ACCOUNT_NAME", None)  # fuerza el almacén en memoria

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

c = TestClient(app)
DON = {"donante": "Restaurante Sol", "descripcion": "20 porciones de arroz", "kg": 10,
       "distrito": "Callao", "hora_limite": "hoy 9:00 p. m."}


def test_health():
    assert c.get("/health").json() == {"status": "ok"}


def test_flujo_completo_y_impacto():
    r = c.post("/api/donaciones", json=DON)
    assert r.status_code == 201
    id_ = r.json()["id"]
    assert any(i["id"] == id_ for i in c.get("/api/donaciones?estado=disponible").json())

    r = c.post(f"/api/donaciones/{id_}/reclamar", json={"organizacion": "Olla Esperanza"})
    assert r.status_code == 200 and r.json()["estado"] == "reclamada"

    assert c.post(f"/api/donaciones/{id_}/reclamar", json={"organizacion": "Otra"}).status_code == 409
    imp = c.get("/api/impacto").json()
    assert imp["kg_rescatados"] >= 10 and imp["raciones_estimadas"] >= 25


def test_validacion_y_404():
    assert c.post("/api/donaciones", json={**DON, "kg": -1}).status_code == 422
    assert c.post("/api/donaciones/noexiste/reclamar", json={"organizacion": "X1"}).status_code == 404


def test_asistente_modo_demo():
    os.environ.pop("AZURE_OPENAI_ENDPOINT", None)
    assert "demostración" in c.post("/api/asistente", json={"texto": "hola"}).json()["respuesta"]
